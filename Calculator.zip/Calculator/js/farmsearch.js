$().ready(function() {

  var cart=[];
  var y=0;

  if(localStorage.getItem("cartitem") !== undefined && localStorage.getItem("cartitem") !== null) {
    cart=JSON.parse(localStorage.getItem("cartitem"));
    y=JSON.parse(localStorage.getItem("cartcount")) +1;
  }

   ($( "#quantitycow,#weightcow" )).change(function() {
    	var weightcow = $( "#weightcow" ).val();
       
        var quantitycow = $( "#quantitycow" ).val();
       
       if (weightcow=="200-250"){
       
         $('#retailPricecow').html(' <h5>Retail Price</h5> <input class="form-control" id="selcowprice" value="180000" disabled ></input><div  id="retailPricecowdet"></div>');
        weightcowprice=180000;
        price=weightcowprice*quantitycow;
       }
       else if (weightcow=="251-300"){
      
         $('#retailPricecow').html(' <h5>Retail Price</h5> <input class="form-control" id="selcowprice" value="230000" disabled ></input><div  id="retailPricecowdet"></div>');
        weightcowprice=230000;
        price=weightcowprice*quantitycow;
       }
       else if (weightcow=="301-350"){
      
         $('#retailPricecow').html(' <h5>Retail Price</h5> <input class="form-control" id="selcowprice" value="260000" disabled ></input><div  id="retailPricecowdet"></div>');
        weightcowprice=260000;
        price=weightcowprice*quantitycow;
       }
       else if (weightcow=="351-400"){
      
         $('#retailPricecow').html(' <h5>Retail Price</h5> <input class="form-control" id="selcowprice" value="320000" disabled ></input><div  id="retailPricecowdet"></div>');
        weightcowprice=320000;
        price=weightcowprice*quantitycow;
       }
       else if (weightcow=="401-500"){
      
         $('#retailPricecow').html(' <h5>Retail Price</h5> <input class="form-control" id="selcowprice" value="400000" disabled ></input><div  id="retailPricecowdet">*(Subject To Changes)</div>');
        
        weightcowprice=400000;
        price=weightcowprice*quantitycow;
       }
        $('#exploretablecow').find('center').remove().end();
         $('#exploretablecow').html('<h5>Total Price</h5> <input class="form-control" id="selcowtotalprice" value="'+price+'" disabled ></input>');

       
        });

        ($( "#quantitygoat,#weightgoat" )).change(function() {
          var weightgoat = $( "#weightgoat" ).val();
           
            var quantitygoat = $( "#quantitygoat" ).val();
           
           if (weightgoat=="10-15"){
        
             $('#retailPricegoat').html('<h5>Retail Price</h5> <input class="form-control" id="selgoatprice" value="20000" disabled ></input><div  id="retailPricegoatdet"></div>');
            weightgoatprice=20000;
            price=weightgoatprice*quantitygoat;
           }
           else if (weightgoat=="16-30"){
       
             $('#retailPricegoat').html('<h5>Retail Price</h5> <input class="form-control" id="selgoatprice" value="30000" disabled ></input><div  id="retailPricegoatdet"></div>');
            weightgoatprice=30000;
            price=weightgoatprice*quantitygoat;
           }
           else if (weightgoat=="31+"){
       
             $('#retailPricegoat').html('<h5>Retail Price</h5> <input class="form-control" id="selgoatprice" value="45000" disabled ></input><div  id="retailPricegoatdet"></div>');
            weightgoatprice=45000;
            price=weightgoatprice*quantitygoat;
           }
          
           
             $('#exploretablegoat').html('<h5>Total Price</h5> <input class="form-control" id="selgoattotalprice" value="'+price+'" disabled ></input>');
    
           
            });

            ($( "#quantityram,#weightram" )).change(function() {
              var weightram = $( "#weightram" ).val();
               
                var quantityram = $( "#quantityram" ).val();
                if (weightram=="10-15"){
        
             $('#retailPriceram').html('<h5>Retail Price</h5> <input class="form-control" id="selramprice" value="20000" disabled ></input><div  id="retailPriceramdet"></div>');
            weightramprice=20000;
            price=weightramprice*quantityram;
           }
           else if (weightram=="16-30"){
       
             $('#retailPriceram').html('<h5>Retail Price</h5> <input class="form-control" id="selramprice" value="30000" disabled ></input><div  id="retailPriceramdet"></div>');
            weightramprice=30000;
            price=weightramprice*quantityram;
           }
           else if (weightram=="31+"){
       
             $('#retailPriceram').html('<h5>Retail Price</h5> <input class="form-control" id="selramprice" value="45000" disabled ></input><div  id="retailPriceramdet"></div>');
            weightramprice=45000;
            price=weightramprice*quantityram;
           }
          
           
             $('#exploretableram').html('<h5>Total Price</h5> <input class="form-control" id="selramtotalprice" value="'+price+'" disabled ></input>');
    
           
               
                });
       





  ($( "#ramform" )).on("submit" ,function(e) {
    
  

              var weightram = $( "#weightram" ).val();
               
                var quantityram = $( "#quantityram" ).val();

                  var selramprice= $( "#selramprice" ).val();

                    var selramtotalprice = $( "#selramtotalprice" ).val();

  if (weightram!=0 && quantityram!="" && selramprice!=undefined && selramtotalprice!=undefined) {

                cart[y]={"animal":"ram","weight":weightram ,"quantity":quantityram,"price":selramprice,"totalprice":selramtotalprice};

                 localStorage.setItem("cartitem", JSON.stringify(cart));
                 localStorage.setItem("cartcount", JSON.stringify(y));


        
               y++;

               // Get the modal
var modal = document.getElementById("myModal");


// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

$("#modal-body").html('<p>'+quantityram+' Rams of weight '+weightram+' Added To Cart</p>');



  modal.style.display = "block";

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
}else{
  var modal = document.getElementById("myModal");

$(".modal-header-title").html('<h3>Error</h3>');

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

$("#modal-body").html('<p>Blank Values</p>');



  modal.style.display = "block";

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 
       
}
             
                });

  ($( "#cowform" )).on("submit" ,function(e) {
    
  

              var weightcow = $( "#weightcow" ).val();
               
                var quantitycow = $( "#quantitycow" ).val();

                  var selcowprice= $( "#selcowprice" ).val();

                    var selcowtotalprice = $( "#selcowtotalprice" ).val();
 if (weightcow!=0 && quantitycow!="" && selcowprice!=undefined && selcowtotalprice!=undefined) {
                 cart[y]={"animal":"cow","weight":weightcow ,"quantity":quantitycow,"price":selcowprice,"totalprice":selcowtotalprice};
                 localStorage.setItem("cartitem", JSON.stringify(cart));
              
     localStorage.setItem("cartcount", JSON.stringify(y));


           

             
        
               y++;
                          // Get the modal
var modal = document.getElementById("myModal");


// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

$("#modal-body").html('<p>'+quantitycow+' Cows of weight '+weightcow+' Added To Cart</p>');



  modal.style.display = "block";

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
}else {
       var modal = document.getElementById("myModal");


$(".modal-header-title").html('<h3>Error</h3>');

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

$("#modal-body").html('<p>Blank Values</p>');



  modal.style.display = "block";

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 
       
}
                });
  ($( "#goatform" )).on("submit" ,function(e) {
    
  

              var weightgoat = $( "#weightgoat" ).val();
               
                var quantitygoat = $( "#quantitygoat" ).val();

                  var selgoatprice= $( "#selgoatprice" ).val();

                    var selgoattotalprice = $( "#selgoattotalprice" ).val();
                    if (weightgoat!=0 && quantitygoat!="" && selgoatprice!=undefined && selgoattotalprice!=undefined) {
                      console.log(selgoatprice);
                 cart[y]={"animal":"goat","weight":weightgoat ,"quantity":quantitygoat,"price":selgoatprice,"totalprice":selgoattotalprice};
                 localStorage.setItem("cartitem", JSON.stringify(cart));
              
 localStorage.setItem("cartcount", JSON.stringify(y));


                     // Get the modal
var modal = document.getElementById("myModal");


// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

$("#modal-body").html('<p>'+quantitygoat+' Goats of weight '+weightgoat+' Added To Cart</p>');



  modal.style.display = "block";

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 

             
        
               y++;
             }else {
                                   // Get the modal
var modal = document.getElementById("myModal");


$(".modal-header-title").html('<h3>Error</h3>');

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

$("#modal-body").html('<p>Blank Values</p>');



  modal.style.display = "block";

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 
             }
             
                });
     });
                
  